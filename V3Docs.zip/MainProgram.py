import requests
import pandas as pd
import os
import json
import subprocess
import sys
import urllib3
import uuid
import atexit
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


def on_exit():
    print("Exiting program. Saving data...") 


atexit.register(on_exit)

def CinNumberGetter(csvPath):
    df = pd.read_csv(csvPath)

    cinNumList = []
    for i in  df['CIN']:
        cinNumList.append(i)

    return cinNumList

def DocumentCategoryFolder(docDownloadPath):
    if not os.path.exists(docDownloadPath):
        try:
            os.makedirs(docDownloadPath)
        except:
            print('failed to create folder')
    else:
        pass
        # print('folder is there')

def main():

    with open('userdata.json', 'r') as file:
        loaded_data = json.load(file)

    cinCsvPath = loaded_data['CINCSVPath']

    url = 'https://api2.finanvo.in/user/login'

    session = requests.Session()

    headers = {
        'Accept': 'application/json, text/plain, */*',
        'Accept-Encoding': 'gzip, deflate, br',
        'Accept-Language': 'en-US,en;q=0.9',
        'App-Origin': 'https://finanvo.in',
        'Authorization': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NDcxMywibmFtZSI6InNhbmRpcHBhbmtoYW5peWE1NiIsImVtYWlsIjoic2FuZGlwcGFua2hhbml5YTU2QGdtYWlsLmNvbSIsInBfaWQiOm51bGwsIkFQSV9LRVkiOiJDU2hTNWl6b2QzIiwiQVBJX1NFQ1JFVF9LRVkiOiJDZ3BhNEkzOTh2ZnRGNGxIRU5heG5nc3FNek00c3UyRW5Ebzg1Wk9wIiwiUElOQ09ERSI6bnVsbCwiVEVBTV9JRCI6bnVsbCwiaWF0IjoxNzA0NzgzMDQ5LCJleHAiOjE3MDQ3OTAyNDl9.DGD-IJwf8QxNHuw6TD7peahV0FI1lRMgA2DllYm-k9k',
        'Connection': 'keep-alive',
        'Content-Length': '54',
        'Content-Type': 'application/json',
        'Host': 'api2.finanvo.in',
        'Ipaddress': '49.36.67.67',
        'Origin': 'https://finanvo.in',
        'Referer': 'https://finanvo.in/',
        'Sec-Ch-Ua': '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
        'Sec-Ch-Ua-Mobile': '?0',
        'Sec-Ch-Ua-Platform': '"Windows"',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-site',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Visitorid': 'ecff3f1792f6cc6e723ad52577e0db89'
    }

    data = {
        'email': loaded_data['Useremail'],
        'password': loaded_data['Userpassword']
    }

    # POST request using the session object
    response = session.post(url, json=data, headers=headers)

    if response.status_code == 200:
        result = response.json()
        # Process the result here

        # Example: Making another request using the same session
        # response = session.get('https://api2.finanvo.in/some-other-endpoint', headers=headers)
        # Handle the response accordingly
        
        print(result['message'])

        # access_token = 'YOUR_ACCESS_TOKEN_HERE'
        authToken = result['data']['token']
        headers = {
            # Your headers here
            # 'Authorization': f'Bearer {headers["Authorization"]}',
            'Authorization': authToken,

            # Other headers...
        }


        CINNumberList = CinNumberGetter(cinCsvPath)

        for cinNum in CINNumberList:
            print('CINMUMBER IS  : ', cinNum)
            pageUrl = f'https://api2.finanvo.in/company/v3-documents?CIN={cinNum}'
            cinNumber = cinNum
        # cinNumber = 'L17110MH1973PLC019786'
        # pageUrl = 'https://api2.finanvo.in/company/v3-documents?CIN=L17110MH1973PLC019786'

        userFolderPath =  loaded_data['FolderPath']
        folderName = rf"{userFolderPath}\{pageUrl.split('=')[-1]}"

        if not os.path.exists(folderName):
            try:
                os.makedirs(folderName)
            except:
                print('failed to create folder')
        else:
            print('folder is there')

        pageResponse = session.get(pageUrl, headers=headers)
        # pageResponse = session.get(pageUrl)


        
        try:
            if pageResponse.status_code == 200:
                pageResult = pageResponse.json()
                
                print(f"Total Documents are there : {len(pageResult['data'])}")
                allPdfListDetails = []
                failedDoc = 0
                for index,singlePageResult in enumerate(pageResult['data'],start=1):
                    try:
                        fileName = singlePageResult['fileName']
                        donwloadUrl = singlePageResult['download_url']

                        documentCategory = singlePageResult['documentCategory']

                        if documentCategory == 'Other eForm Documents':
                            docDownloadPath = fr'{folderName}\{documentCategory}'
                            DocumentCategoryFolder(docDownloadPath)
                        elif documentCategory == 'Certificates':
                            docDownloadPath = fr'{folderName}\{documentCategory}'
                            DocumentCategoryFolder(docDownloadPath)
                        elif documentCategory == 'Charge Documents':
                            docDownloadPath = fr'{folderName}\{documentCategory}'
                            DocumentCategoryFolder(docDownloadPath)
                        else:
                            docDownloadPath = fr'{folderName}\{documentCategory}'
                            DocumentCategoryFolder(docDownloadPath)
                        

                        pdfResponse = session.get(donwloadUrl, verify=False)

                        if pdfResponse.status_code == 200:
                            fileRelatedInfo = pdfResponse.headers['content-disposition']
                            fileExtension  =  fileRelatedInfo.split('.')[-1]
                            fileName = fileRelatedInfo.split('.')[0].split('=')[-1]

                            filePath = rf'{docDownloadPath}\{fileName}_{str(uuid.uuid4().fields[-1])[:6]}.{fileExtension}'
                            with open(filePath, 'wb') as file:
                                file.write(pdfResponse.content)
                            fileStatus = 'Success'
                        else:
                            # print('not done')
                            fileStatus = 'Failure'
                            filePath = ''
                            failedDoc += 1
                        
                        print(f'\rProcess complete {index}/{len(pageResult["data"])}', end='', flush=True)
                        print(f', Download Failed File Count: {failedDoc}', end='', flush=True)
                        # print(f'\rProcess complete {index}/{len(pageResult["data"])}\nDownload Failed File Count: {failedDoc}', end='', flush=True)

                        
                        allPdfListDetails.append([cinNumber,fileName,fileStatus,filePath])
                    except Exception as e:
                        pass
    
                # Create a DataFrame from the list
                df = pd.DataFrame(allPdfListDetails, columns=['CINNumber','FileName' ,'DownloadFileStatus','FilePath'])

                # Specify the file path where you want to save the CSV file
                csv_file_path = loaded_data['OutputCSVPath']

                # Write the DataFrame to a CSV file
                df.to_csv(csv_file_path, index=False)
                
        except Exception as e:
                df = pd.DataFrame(allPdfListDetails, columns=['CINNumber','FileName' ,'DownloadFileStatus','FilePath'])

                # Specify the file path where you want to save the CSV file
                
                csv_file_path = loaded_data['OutputCSVPath']
                # Write the DataFrame to a CSV file
                df.to_csv(csv_file_path, index=False)
                # print(e)
        else:
            print(f'error : {pageResponse.status_code} - {pageResponse.text}')

    else:
        print(f"Error: {response.status_code} - {response.text}")

# main()
if __name__ == "__main__":
    try:
        main()
        # success_msg = 'all process done'
        # if sys.argv[0].endswith('.exe'):
        #     subprocess.call(['cmd', '/k', 'echo', success_msg , '&', 'pause'])
        # else:
        #     input("Press Enter to exit...")
    except Exception as e:
        # If an exception occurs, display the error message in a console window
        error_msg = f"An error occurred: {e}"
        print(error_msg)

        # Open a command prompt window to show the error before closing
        if sys.argv[0].endswith('.exe'):
            subprocess.call(['cmd', '/k', 'echo', error_msg, '&', 'pause'])
        else:
            input("Press Enter to exit...")